//
//  ViewController.swift
//  SwiftLearning
//
//  Created by Vidya Darade on 14/03/18.
//  Copyright © 2018 WeAre-Beyond Horizon. All rights reserved.
//

import UIKit

class ViewController: UIViewController{
    //Optional - Optional means it will have value or nil
    //Declaration
    //Use
    //Forced unwrapping
    //Automatic unwrapping
    //Optional Binding
    
   
    var intMayBe : Int?
    var name : String?
    var sirName : String?
    var companyName : String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
      //printing optional value
        
        if name != nil{
            print("without unwrapping optional value \(name)")
        }else{
            print("Value is nil : -- \(name)")
        }
        
        print("-------------------------------------------------")
        
        // assign some value to optional string
        
        name = "WeAre - Beyond Horizon"
        
        if name != nil{
            print("without unwrapping optional value : -- \(name)")
        }else{
            print("Value is nil : -- \(name)")
        }
         print("-------------------------------------------------")
        // 1.Force unwrapping using exclamation mark----------
        
        if name != nil{
            print("with forced unwrapping optional value : -- \(name!)")
        }else{
            print("Value is nil : -- \(name!)")
        }
         print("-------------------------------------------------")
        // 2.nil coalescing operator----------------
        
        if sirName != nil{
            print("with nil coalescing operator : -- \(sirName ?? "Here we are")")
        }else{
            print("Value is nil : -- \(sirName ?? "Here we are")")
        }
         print("-------------------------------------------------")
        sirName = "Coders"
        
        if sirName != nil{
            print("with nil coalescing operator : -- \(sirName ?? "Here we are")")
        }else{
            print("Value is nil : -- \(sirName ?? "Here we are")")
        }
         print("-------------------------------------------------")
        // 3.Optional Binding--------------
        
        // when no value
        
        if let tempstr = companyName{
            print(tempstr)
        }else{
            print("no value")
        }
         print("-------------------------------------------------")
        
       //when assined value
        companyName = "-WeAre-"
        
        
        if let tempstr = companyName{
            print(tempstr)
        }else{
            print("no value")
        }
        print("-------------------------------------------------")
    }


}

